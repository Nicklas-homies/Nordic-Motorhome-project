package com.nmh.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NmHprojectApplication {

    public static void main(String[] args) {
        SpringApplication.run(NmHprojectApplication.class, args);
    }

}
